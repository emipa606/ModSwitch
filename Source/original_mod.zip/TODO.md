- Combine search boxes with highlight/hide feature
x import/export for settings
x cloud sync for settings
- centralize language definitions to eliminate duplicates across versions